package com.endUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndUserAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndUserAppApplication.class, args);
	}

}
